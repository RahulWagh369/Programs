package Com.Ecommarce.Utilities;

public class WaitUtils {
	
	public static int IMPLICIT_WAIT = 15;
	public static int PAGE_LOAD_TIMEOUT=15;

}
